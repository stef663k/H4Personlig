/*
 * ProjectDefines.h
 *
 * Created: 23-06-2023 10:15:41
 *  Author: ltpe
 */ 

#include <avr/io.h>

#ifndef PROJECTDEFINES_H_
#define PROJECTDEFINES_H_


//#if defined(_AVR_IOM2560_H_1)
//
//#define TWI_TWSR ICR5H
//#define TWI_TWDR ICR5H
//#define TWI_TWCR ICR5H
//#define TWI_TWBR ICR5H
//
//#endif

//#if defined (_AVR_ATMEGA328PB_H_INCLUDED)
//#define TWI_TWSR 1
//#define TWI_TWDR 2
//#define TWI_TWCR 3
//#define TWI_TWBR 4
//#endif



#endif /* PROJECTDEFINES_H_ */