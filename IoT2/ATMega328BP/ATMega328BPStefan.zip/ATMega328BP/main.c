#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/io.h>
#include "bitwise_operations.h"
#include "UART.h"

uint16_t Add8BitNumbers(uint8_t Number1, uint8_t Number2) {
	return (Number1 + Number2);
}

int main(void) {
	RS232Init();

	uint8_t Var1 = 0xF8;
	uint8_t Var2 = 0x01;


	sei();

	simulateBitSetting(Var1);

	uint8_t logicalOr = Var1 || Var2; // Result will be 1 (true)
	uint8_t logicalAnd = Var1 && Var2; // Result will be 1 (true)

	uint8_t bitwiseOr = Var1 | Var2; // Result: 0xF9
	uint8_t bitwiseAnd = Var1 & Var2; // Result: 0x00

	uint16_t AddResult = Add8BitNumbers(0xAA, 0xBB); 
	
	UART_PrintString("Initial Value: 0x");
	UART_PrintHex(Var1);
	UART_PrintString(" (binary: ");
	UART_PrintBinary(Var1);  
	UART_PrintString(")\n");

	for (int bit_position = 0; bit_position < 8; bit_position++) {
		Var1 = 0xF8;

		Var1 |= (1 << bit_position);

		UART_PrintString("Setting bit position ");
		UART_PrintHex(bit_position);
		UART_PrintString(": 0x");
		UART_PrintHex(Var1);
		UART_PrintString(" (binary: ");
		UART_PrintBinary(Var1);
		UART_PrintString(")\n");
	}



	DDRB = 0xFF; 

	PORTB = (1 << PB4) | (1 << PB2); 
	PORTB |= (1 << PB0); 
	PORTB &= ~(1 << PB2);
	PORTB &= ~((1 << PB7) | (1 << PB6)); 

	uint8_t combinedOr = (Var1 != 0) | (Var2 != 0); 
	uint8_t combinedOrWithVar1 = (Var1 != 0) || (Var2 != 0) | Var1;

	while (1) {
		//UART_PrintString("A");
		//_delay_ms(1000);
	}

	return 0; 
}
