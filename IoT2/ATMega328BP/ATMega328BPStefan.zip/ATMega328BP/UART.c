#include "UART.h"
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "ProjectDefines.h"
#include "Main.h"

static FILE uart_output = FDEV_SETUP_STREAM(uart_putch, NULL, _FDEV_SETUP_WRITE);
static FILE uart_input = FDEV_SETUP_STREAM(NULL, uart_getch, _FDEV_SETUP_READ);

void RS232Init(void) {
	UBRRL = (unsigned char)(MyUBRR & 0xff);
	UBRRH = (unsigned char)(MyUBRR >> 8);
	
	#ifdef UART_NORMAL_MODE
	UCSRA = 0x00;
	#else
	UCSRA = (1 << U2X);
	#endif

	UCSRB = (1 << RXEN) | (1 << TXEN);
	UCSRC = (1 << UCSZ1) | (1 << UCSZ0);

	stdout = &uart_output;
	stdin = &uart_input;
}

void Enable_UART_Receive_Interrupt() {
	UCSRB |= (1 << RXCIE);
}

void Disable_UART_Receive_Interrupt() {
	UCSRB &= ~(1 << RXCIE);
}

int uart_getch(FILE* stream) {
	while (!(UCSRA & (1 << RXC)));
	return UDR;
}

int uart_putch(char ch, FILE* stream) {
	while (!(UCSRA & (1 << UDRE)));
	UDR = ch;
	return 0;
}

ISR(USART_RX_vect) {
	char ReceivedByte = UDR;
	ReceiveNewTimeoutValue(&ReceivedByte);
}

void UART_PrintString(const char* str) {
	while (*str) {
		uart_putch(*str++, NULL);
	}
}

void UART_PrintChar(char c) {
	uart_putch(c, NULL);
}

void UART_PrintHex(uint8_t value) {
	const char hexDigits[] = "0123456789ABCDEF";
	uart_putch(hexDigits[value >> 4], NULL); // Send high nibble
	uart_putch(hexDigits[value & 0x0F], NULL); // Send low nibble
}

void UART_PrintBinary(uint8_t value) {
    for (int i = 7; i >= 0; i--) {
	    char bit = (value >> i) & 1 ? '1' : '0';
	    UART_PrintString(&bit);
    }
}

